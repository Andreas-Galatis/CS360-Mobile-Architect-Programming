package com.example.cs360_m5_option3_weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.cs360_m5_option3_weighttrackingapp.models.WeightModel;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WeightsDBHelper extends SQLiteOpenHelper {

    // database information
    private static final String DATABASE_NAME = "weights.db";
    private static final int VERSION = 2;

    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_WEIGHT = "WEIGHT";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_DATE = "DATE";

    public WeightsDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // create table query
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + WEIGHT_TABLE
                + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " DATE, "
                + COLUMN_WEIGHT + " DOUBLE " + ") ;";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + WEIGHT_TABLE);
        onCreate(db);
    }

    // ADD to the database
    public boolean addOne(WeightModel weightModel)  {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_DATE, weightModel.getDate());
        cv.put(COLUMN_WEIGHT, weightModel.getWeight());

        long insert = db.insert(WEIGHT_TABLE, null, cv);
        if (insert == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    // UPDATE item in database
    public boolean updateOne(WeightModel weightModel) {
        // find entry in database
        // if found update and return true, else false
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        String queryString = "DELETE FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_ID + " = " + weightModel.getId();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    // DELETE from the database
    public boolean deleteOne(WeightModel weightModel) {
        // find entry in database
        // if found delete and return true, else false
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_ID + " = " + weightModel.getId();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    // LIST the database
    public List<WeightModel> getList() {
        List<WeightModel> returnList = new ArrayList<>();

        // get data from the database
        String queryString = "SELECT * FROM " + WEIGHT_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            // loop through the cursor and create new object
            do {
                int objectID = cursor.getInt(0);
                String objectDate = cursor.getString(1);
                Double objectWeight = cursor.getDouble(2);

                WeightModel newWeight = new WeightModel(objectID, objectDate, objectWeight);
                returnList.add(newWeight);

            }while (cursor.moveToNext());
        }
        else {
            // failure. Do not add anything to the list
        }

        // close cursor and db
        cursor.close();
        db.close();

        return returnList;
    }

    // LIST the database
    public List<WeightModel> getDate() {
        List<WeightModel> returnDateList = new ArrayList<>();

        // get data from the database
        String queryString = "SELECT * FROM " + WEIGHT_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            // loop through the cursor and create new object
            do {
                int objectID = cursor.getInt(0);
                String objectDate = cursor.getString(1);



                WeightModel newWeight = new WeightModel(objectID, objectDate, null);

                returnDateList.add(newWeight);

            }while (cursor.moveToNext());
        }
        else {
            // failure. Do not add anything to the list
        }

        // close cursor and db
        cursor.close();
        db.close();

        return returnDateList;
    }


}




















