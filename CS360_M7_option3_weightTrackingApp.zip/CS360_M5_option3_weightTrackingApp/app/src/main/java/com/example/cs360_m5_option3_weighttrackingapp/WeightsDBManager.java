/*
package com.example.cs360_m5_option3_weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.SimpleCursorAdapter;

import java.util.Date;

public class WeightsDBManager {

    private WeightsDBHelper dbHelper;
    private Context context;
    private static SQLiteDatabase database;

    public WeightsDBManager(Context c) {
        context = c;
    }

    // open database connection
    public  WeightsDBManager open() throws SQLException {
        dbHelper = new WeightsDBHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    // close database connection
    public void close() {
        dbHelper.close();
    }

    // insert a new record to database
    public static void insert(Date date, Double weight) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(WeightsDBHelper.DATE, String.valueOf(date));
        contentValues.put(WeightsDBHelper.WEIGHT, weight);
        database.insert(WeightsDBHelper.TABLE, null, contentValues);
    }

    // update a record in the database
    public int update(long _id, Date date, Double weight) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(WeightsDBHelper.DATE, String.valueOf(date));
        contentValues.put(WeightsDBHelper.WEIGHT, weight);
        int i = database.update(WeightsDBHelper.TABLE, contentValues,
                WeightsDBHelper._ID + " = " + _id, null);
        return i;
    }

    // cursor function
    public static Cursor fetch() {
        String[] columns = new String[] { WeightsDBHelper._ID, WeightsDBHelper.DATE, WeightsDBHelper.WEIGHT};
        Cursor cursor = database.query(WeightsDBHelper.TABLE, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    // delete from database
    public void delete(long _id){
        database.delete(WeightsDBHelper.TABLE, WeightsDBHelper._ID + " = " + _id, null);
    }

    public SimpleCursorAdapter displayList() {
        String columns[] = {WeightsDBHelper._ID, WeightsDBHelper.DATE, WeightsDBHelper.WEIGHT};
        Cursor cursor = database.query(WeightsDBHelper.TABLE, columns, null, null, null, null, null);
        String [] fromFieldNames = new String[] {
                WeightsDBHelper._ID, WeightsDBHelper.DATE, WeightsDBHelper.WEIGHT
        };
        int [] toViewIDs = new int [] {R.id.item_id, R.id.item_date, R.id.item_weight};
        SimpleCursorAdapter contactAdapter = new SimpleCursorAdapter(
                context,
                R.layout.single_item,
                cursor,
                fromFieldNames,
                toViewIDs
        );
        return contactAdapter;
    }
}


*/

















