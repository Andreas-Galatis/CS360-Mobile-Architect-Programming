package com.example.cs360_m5_option3_weighttrackingapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cs360_m5_option3_weighttrackingapp.R;
import com.example.cs360_m5_option3_weighttrackingapp.WeightsDBHelper;
import com.example.cs360_m5_option3_weighttrackingapp.models.WeightModel;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataActivity extends AppCompatActivity  {

    private int SMS_PERMISSION_CODE = 1;


    // member variables
    EditText enterDate, enterWeight;
    Button enterBtn, buttonRequest;
    ListView weightList;
    private ListView listView;
    ArrayAdapter weightListAdapter;
    WeightsDBHelper weightsDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // references to buttons and other controls on the layout
        enterDate = (EditText) findViewById(R.id.enterDate);
        enterWeight = (EditText) findViewById(R.id.enterWeight);
        enterBtn = (Button) findViewById(R.id.enterBtn);
        listView = (ListView) findViewById(R.id.list_view);

        // declared database helper object
        weightsDBHelper = new WeightsDBHelper(DataActivity.this);

        // declared database array adapter to list weight inputs
        weightListAdapter = new ArrayAdapter<WeightModel>(DataActivity.this,
                android.R.layout.simple_list_item_1, weightsDBHelper.getList());
        listView.setAdapter(weightListAdapter);

        // Button listener function to add weight
        enterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // new instance of dbhelper
                WeightsDBHelper weightsDBHelper = new WeightsDBHelper(DataActivity.this);
                WeightModel weightModel;
                try {
                    weightModel = new WeightModel(-1, (enterDate.getText().toString()), Double.parseDouble(enterWeight.getText().toString()));
                    weightsDBHelper.addOne(weightModel);
                    Toast.makeText(DataActivity.this, "Added new entry", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(DataActivity.this, " Error during input", Toast.LENGTH_SHORT).show();

                }

                // list array
                weightListAdapter = new ArrayAdapter<WeightModel>(DataActivity.this, android.R.layout.simple_list_item_1, weightsDBHelper.getList());

                // updates the listview with the list array
                listView.setAdapter(weightListAdapter);

                enterDate.setText("");
                enterWeight.setText("");

            }

        });

        Button buttonRequest = findViewById(R.id.notification_btn);
        buttonRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(( DataActivity.this),
                        Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(DataActivity.this, "You have granted this permission already", Toast.LENGTH_SHORT).show();
                } else {
                    requestStoragePermission();
                }
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                WeightModel clickedEntry = (WeightModel) parent.getItemAtPosition(position);
                weightsDBHelper.deleteOne(clickedEntry);
                ShowWeightListOnListView(weightsDBHelper);
                Toast.makeText(DataActivity.this, "Deleted entry", Toast.LENGTH_SHORT).show();


            }
        });
    }

    private void ShowWeightListOnListView(WeightsDBHelper weightsDBHelper) {
        weightListAdapter = new ArrayAdapter<WeightModel>(DataActivity.this, android.R.layout.simple_list_item_1, weightsDBHelper.getList());
        listView.setAdapter(weightListAdapter);
    }

    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed to send text message notifications")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(DataActivity.this,
                                    new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, SMS_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, SMS_PERMISSION_CODE);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }

}