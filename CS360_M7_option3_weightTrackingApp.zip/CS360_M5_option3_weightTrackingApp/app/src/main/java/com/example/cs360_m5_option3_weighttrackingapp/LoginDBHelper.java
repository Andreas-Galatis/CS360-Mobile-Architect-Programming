package com.example.cs360_m5_option3_weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "login.db";
    private static final int VERSION = 1;

    public LoginDBHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // called first time a database is accessed to create new DB for login
    @Override
    public void onCreate(SQLiteDatabase loginDB) {
        loginDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    // called if there are version changes to the database
    @Override
    public void onUpgrade(SQLiteDatabase loginDB, int i, int i1) {
        loginDB.execSQL("drop Table if exists users");
    }

    // add new user
    public Boolean newUser(String username, String password) {
        SQLiteDatabase loginDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = loginDB.insert("users", null, contentValues);
        if (result == -1) return false;
        else
            return true;
    }

    // check if username already exists
    public Boolean checkUserName(String username) {
        SQLiteDatabase loginDB = this.getWritableDatabase();
        Cursor cursor = loginDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    // checks if username and password is a match
    public Boolean checkUsernameAndPassword(String username, String password) {
        SQLiteDatabase loginDB = this.getWritableDatabase();
        Cursor cursor = loginDB.rawQuery("Select * from users where username = ? and password = ?",
                new String[]{username, password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
}
