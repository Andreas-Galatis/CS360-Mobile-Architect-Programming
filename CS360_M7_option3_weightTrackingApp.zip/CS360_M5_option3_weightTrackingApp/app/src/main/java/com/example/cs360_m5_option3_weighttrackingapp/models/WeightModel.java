package com.example.cs360_m5_option3_weighttrackingapp.models;

import java.util.Date;

public class WeightModel {

    // data members
    private int id;
    private String date;
    private Double weight;

    // Constructors
    public WeightModel() {}

    public WeightModel(int id, String date, Double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;

    }

    // Getters
    public int getId() { return id; }

    public String getDate()  { return date; }

    public Double getWeight() { return weight; }


    // Setters
    public void setId(int id) { this.id = id; }

    public void setDate(String date) { this.date = date; }

    public void setWeight(Double weight) { this.weight = weight; }

    @Override
    public String toString() {
        return  (date + "        " + weight + " lbs");
    }

}
