package com.example.cs360_m5_option3_weighttrackingapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cs360_m5_option3_weighttrackingapp.LoginDBHelper;
import com.example.cs360_m5_option3_weighttrackingapp.R;

public class MainActivity extends AppCompatActivity {

    // local variable declarations
    EditText username, password;
    Button login, register;
    LoginDBHelper loginDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // assign variables to layout activity parameters
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.loginButton);
        register = (Button) findViewById(R.id.registerButton);
        loginDB = new LoginDBHelper(this);

        // onclick listener function for the login button
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // check if username and password matches database when user clicks login
                Boolean checkUserPass = loginDB.checkUsernameAndPassword(user, pass);
                if(checkUserPass) {
                    Toast.makeText(MainActivity.this, "Sign in successful", Toast.LENGTH_SHORT).show();
                    Intent intent  = new Intent(getApplicationContext(), DataActivity.class);
                    startActivity(intent);
                } else{
                    Toast.makeText(MainActivity.this, "Invalid credentials - If first time please Register",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        // onclick listener function for the register button
        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick( View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // makes sure user enters all the fields
                Boolean checkUser = null;
                Boolean insert = null;
                if (user.equals("") || pass.equals(""))
                    Toast.makeText(MainActivity.this, "Please enter all the fields",
                            Toast.LENGTH_SHORT).show();
                else {
                    // check is username and password exists in database
                    checkUser = loginDB.checkUserName(user);
                    insert = null;
                }
                // if user not in database then register new user
                if (!checkUser) {
                    insert = loginDB.newUser(user, pass);
                    if (insert) {
                        Toast.makeText(MainActivity.this, "Registered successfully",
                                Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), DataActivity.class);
                        startActivity(intent);  // if registration good - screen goes to main data page
                    } else{
                        Toast.makeText(MainActivity.this, "Registration failed",
                                Toast.LENGTH_SHORT).show();
                    }
                } else{
                    Toast.makeText(MainActivity.this, "User already exists! please use login",
                            Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
